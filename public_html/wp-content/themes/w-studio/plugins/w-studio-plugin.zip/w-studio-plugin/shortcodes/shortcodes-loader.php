<?php

/* Load Shortcodes */
require_once W_STUDIO_PLUGIN_DIR . '/shortcodes/shortcodes.php';

//if( is_admin() ) {
//    // Check if Visual Composer is installed
//    if ( ! defined( 'WPB_VC_VERSION' ) ) {
//        
//        
//    } else {
//        /* Load VC Addon  */
//        require_once W_STUDIO_PLUGIN_DIR . '/shortcodes/vc-addon.php';
//    }
//}