<?php
// Loading Instagram Widget
require_once dirname( __FILE__ ) . '/instagram/ws-widget-instagram.php';
// Loading Twitter Widget
require_once dirname( __FILE__ ) . '/twitter/ws-twitter-widget.php';// Loading Social media widgetrequire_once dirname( __FILE__ ) . '/ws-social-widget.php';