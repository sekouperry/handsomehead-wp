<?php



// Load MetaBoxes

/* Load Metaboxes For Portfolios */

require_once W_STUDIO_PLUGIN_DIR . '/cpt/metaboxes/portfolio-metabox.php';



/* Load Metaboxes For Team */

require_once W_STUDIO_PLUGIN_DIR . '/cpt/metaboxes/team-metabox.php';



/* Load Metabox For Testimonial */

require_once W_STUDIO_PLUGIN_DIR . '/cpt/metaboxes/testimonial-metabox.php';



/* Load Metabox For Client */

require_once W_STUDIO_PLUGIN_DIR . '/cpt/metaboxes/client-metabox.php';



/* Load Metabox For Client */

require_once W_STUDIO_PLUGIN_DIR . '/cpt/metaboxes/album-metabox.php';