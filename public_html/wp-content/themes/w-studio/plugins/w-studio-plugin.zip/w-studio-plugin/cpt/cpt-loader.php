<?php
// Portfolio Post Type
require_once W_STUDIO_PLUGIN_DIR . '/cpt/cpt/portfolio.php';

// Team Post Type
require_once W_STUDIO_PLUGIN_DIR . '/cpt/cpt/team.php';

// Testimonial Post Type
require_once W_STUDIO_PLUGIN_DIR . '/cpt/cpt/testimonial.php';

// Client Post Type
require_once W_STUDIO_PLUGIN_DIR . '/cpt/cpt/client.php';

// Client Post Type
require_once W_STUDIO_PLUGIN_DIR . '/cpt/cpt/slider.php';

// Client Post Type
require_once W_STUDIO_PLUGIN_DIR . '/cpt/cpt/album.php';